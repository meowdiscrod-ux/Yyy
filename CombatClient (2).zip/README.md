# Combat Client (Fabric 1.21.11, single player)

Pure Java Fabric mod. No native code, so it works on mobile launchers.

## Install
1. Install Fabric Loader for 1.21.11 and the Fabric API mod.
2. Put `combatclient-1.0.0.jar` in your `mods` folder.
3. Press **Right Shift** (main menu or in game) to open the GUI.

## GUI
- Left click a module: toggle.
- Right click a module, or tap the dotted handle on its left: open settings.
- Mouse wheel scrolls a column. Drag sliders.
- Settings save to `config/combatclient.json` when you close the GUI.
- On a phone, lower the Minecraft GUI scale if the five columns look cramped.

## Modules
**Combat**
- **AutoMace**: holding a spear -> long reach, swaps to mace, hits, swaps back. Holding a sword -> swaps to a Breach mace, hits, swaps back. Settings: Aim (Silent/Legit), Aim Speed (Legit only), FOV, Spear Range, Sword Range, Weapon Only, Require Fall, Min Fall, Swap Back, Targets.
- **AutoStunSlam**: axe hit, wait N ticks, mace hit. Settings: Ticks, Range, Weapon Only (must hold an axe), Require Fall, Min Fall, Only Shielded, Swap Back, Targets.
- **TriggerBot**: attacks what is under the crosshair. Settings: Weapon Only, Cooldown (follows the held item), Min Charge, Targets.
- **AimAssist**: pulls the camera to the nearest target. Settings: Aim Speed, FOV, Range, Vertical, Only When Attacking, Weapon Only, Targets.

**Movement** AutoSprint · **Render** Fullbright · **Player** AutoRespawn · **Misc** Colors (hue / saturation / brightness / rainbow, changes the GUI accent).

`Targets` defaults to Hostile so it will not hit villagers or pets. Set it to All to hit any living entity.

## Build on GitHub
Upload this whole folder to a GitHub repo. The workflow in `.github/workflows/build.yml` builds it automatically.
Open the **Actions** tab, open the latest run, download the **CombatClient-1.21.11** artifact, unzip it and use the jar.
