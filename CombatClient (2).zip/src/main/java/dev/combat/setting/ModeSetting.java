package dev.combat.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ModeSetting extends Setting {
    public final String[] modes;
    private int index;

    /** The first mode listed is the default. */
    public ModeSetting(String name, String... modes) {
        super(name);
        this.modes = modes;
    }

    public String get() {
        return modes[index];
    }

    public int index() {
        return index;
    }

    public void set(int i) {
        if (i >= 0 && i < modes.length) index = i;
    }

    public boolean is(String mode) {
        return modes[index].equalsIgnoreCase(mode);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(modes[index]);
    }

    @Override
    public void load(JsonElement e) {
        String s = e.getAsString();
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(s)) {
                index = i;
                return;
            }
        }
    }
}
