package dev.combat.setting;

import com.google.gson.JsonElement;

import java.util.function.BooleanSupplier;

public abstract class Setting {
    public final String name;
    private BooleanSupplier visible = () -> true;

    protected Setting(String name) {
        this.name = name;
    }

    /** Only show this setting in the GUI while the condition is true. */
    public Setting showIf(BooleanSupplier condition) {
        this.visible = condition;
        return this;
    }

    public boolean visible() {
        return visible.getAsBoolean();
    }

    public abstract JsonElement save();

    public abstract void load(JsonElement element);
}
