package dev.combat.module;

import dev.combat.setting.BoolSetting;
import dev.combat.setting.ModeSetting;
import dev.combat.setting.NumSetting;
import dev.combat.util.Combat;
import dev.combat.util.ItemUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;

/** Gently pulls the camera toward the nearest target inside your FOV. */
public class AimAssist extends Module {
    private final NumSetting speed = add(new NumSetting("Aim Speed", 25, 1, 100, 1));
    private final NumSetting fov = add(new NumSetting("FOV", 90, 10, 360, 5));
    private final NumSetting range = add(new NumSetting("Range", 5.0, 3.0, 8.0, 0.1));
    private final BoolSetting vertical = add(new BoolSetting("Vertical", true));
    private final BoolSetting clickOnly = add(new BoolSetting("Only When Attacking", true));
    private final BoolSetting weaponOnly = add(new BoolSetting("Weapon Only", true));
    private final ModeSetting targets = add(new ModeSetting("Targets", "Hostile", "All"));

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        ClientPlayerEntity p = mc.player;
        if (weaponOnly.get() && !ItemUtil.isWeapon(p.getMainHandStack())) return;
        if (clickOnly.get() && !mc.options.attackKey.isPressed()) return;

        LivingEntity t = Combat.find(mc, range.get(), fov.get(), targets.is("Hostile"));
        if (t == null) return;
        float[] rot = Combat.rotsTo(p, t);
        Combat.smooth(p, rot[0], rot[1], speed.get(), vertical.get());
    }
}
