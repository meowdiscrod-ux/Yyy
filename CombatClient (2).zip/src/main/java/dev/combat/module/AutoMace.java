package dev.combat.module;

import dev.combat.setting.BoolSetting;
import dev.combat.setting.ModeSetting;
import dev.combat.setting.NumSetting;
import dev.combat.util.Combat;
import dev.combat.util.ItemUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

/**
 * Two conditions only:
 *  - holding a SPEAR: long reach, swap to mace, hit, swap back.
 *  - holding a SWORD: swap to a Breach mace (if you have one), hit, swap back.
 * Meant to be used while falling from a height (Require Fall).
 */
public class AutoMace extends Module {
    private final ModeSetting aim = add(new ModeSetting("Aim", "Silent", "Legit"));
    private final NumSetting aimSpeed = add(new NumSetting("Aim Speed", 40, 1, 100, 1));
    private final NumSetting fov = add(new NumSetting("FOV", 120, 10, 360, 5));
    private final NumSetting spearRange = add(new NumSetting("Spear Range", 4.0, 3.0, 5.0, 0.1));
    private final NumSetting swordRange = add(new NumSetting("Sword Range", 3.0, 2.5, 5.0, 0.1));
    private final BoolSetting weaponOnly = add(new BoolSetting("Weapon Only", true));
    private final BoolSetting needFall = add(new BoolSetting("Require Fall", true));
    private final NumSetting minFall = add(new NumSetting("Min Fall", 1.6, 1.5, 10.0, 0.1));
    private final BoolSetting swapBack = add(new BoolSetting("Swap Back", true));
    private final ModeSetting targets = add(new ModeSetting("Targets", "Hostile", "All"));

    private int cooldown;

    public AutoMace() {
        super("AutoMace", Category.COMBAT);
        aimSpeed.showIf(() -> aim.is("Legit"));
        minFall.showIf(needFall::get);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (cooldown > 0) cooldown--;
        if (mc.currentScreen != null || Combat.busy) return;

        ClientPlayerEntity p = mc.player;
        ItemStack held = p.getMainHandStack();
        boolean spear = ItemUtil.isSpear(held);
        boolean sword = ItemUtil.isSword(held);
        boolean mace = ItemUtil.isMace(held);

        // "Weapon Only": the module only reacts to the two conditions (spear / sword in hand).
        if (weaponOnly.get() && !(spear || sword)) return;
        if (needFall.get() && !(p.fallDistance > minFall.get())) return;

        double range = spear ? spearRange.get() : swordRange.get();
        LivingEntity target = Combat.find(mc, range, fov.get(), targets.is("Hostile"));
        if (target == null) return;

        float[] rot = Combat.rotsTo(p, target);
        if (aim.is("Legit")) {
            float err = Combat.smooth(p, rot[0], rot[1], aimSpeed.get(), true);
            if (err > 8f) return; // keep aiming, hit once the camera is on target
        }
        if (cooldown > 0) return;

        int maceSlot;
        if (mace) maceSlot = Combat.selected(mc);
        else maceSlot = ItemUtil.findMace(p, sword ? "breach" : "density");
        if (maceSlot < 0) return;

        int prev = Combat.selected(mc);
        Combat.busy = true;
        try {
            if (maceSlot != prev) Combat.select(mc, maceSlot);
            if (aim.is("Silent")) Combat.silentLook(mc, rot[0], rot[1]);
            Combat.attack(mc, target);
        } finally {
            if (swapBack.get() && maceSlot != prev) Combat.select(mc, prev);
            Combat.busy = false;
        }
        cooldown = 12;
    }
}
