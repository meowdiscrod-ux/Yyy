package dev.combat.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;

public class AutoRespawn extends Module {
    public AutoRespawn() {
        super("AutoRespawn", Category.PLAYER);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen instanceof DeathScreen && mc.player.isDead()) {
            mc.player.requestRespawn();
        }
    }
}
