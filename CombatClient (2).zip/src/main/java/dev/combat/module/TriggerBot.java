package dev.combat.module;

import dev.combat.setting.BoolSetting;
import dev.combat.setting.ModeSetting;
import dev.combat.setting.NumSetting;
import dev.combat.util.Combat;
import dev.combat.util.ItemUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Attacks whatever is under the crosshair. The cooldown follows whatever item you hold. */
public class TriggerBot extends Module {
    private final BoolSetting weaponOnly = add(new BoolSetting("Weapon Only", true));
    private final BoolSetting useCooldown = add(new BoolSetting("Cooldown", true));
    private final NumSetting charge = add(new NumSetting("Min Charge", 0.95, 0.5, 1.0, 0.05));
    private final ModeSetting targets = add(new ModeSetting("Targets", "Hostile", "All"));

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
        charge.showIf(useCooldown::get);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null || Combat.busy) return;
        ClientPlayerEntity p = mc.player;
        if (p.isUsingItem()) return;
        if (weaponOnly.get() && !ItemUtil.isWeapon(p.getMainHandStack())) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult ehr)) return;
        Entity e = ehr.getEntity();
        if (!Combat.isValid(e, targets.is("Hostile"))) return;

        if (useCooldown.get() && p.getAttackCooldownProgress(0.5f) < charge.get()) return;
        Combat.attack(mc, e);
    }
}
