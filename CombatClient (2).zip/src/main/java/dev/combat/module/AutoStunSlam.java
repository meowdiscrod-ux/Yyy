package dev.combat.module;

import dev.combat.setting.BoolSetting;
import dev.combat.setting.ModeSetting;
import dev.combat.setting.NumSetting;
import dev.combat.util.Combat;
import dev.combat.util.ItemUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;

/**
 * Axe hit (stuns / disables a shield) -> wait N ticks -> swap to mace and smash -> swap back.
 */
public class AutoStunSlam extends Module {
    private final NumSetting ticks = add(new NumSetting("Ticks", 1, 0, 10, 1));
    private final NumSetting range = add(new NumSetting("Range", 3.5, 2.5, 5.0, 0.1));
    private final BoolSetting weaponOnly = add(new BoolSetting("Weapon Only", true));
    private final BoolSetting needFall = add(new BoolSetting("Require Fall", true));
    private final NumSetting minFall = add(new NumSetting("Min Fall", 1.6, 1.5, 10.0, 0.1));
    private final BoolSetting shieldOnly = add(new BoolSetting("Only Shielded", false));
    private final BoolSetting swapBack = add(new BoolSetting("Swap Back", true));
    private final ModeSetting targets = add(new ModeSetting("Targets", "Hostile", "All"));

    private boolean running;
    private int wait;
    private int prevSlot = -1;
    private int maceSlot = -1;
    private int cooldown;
    private LivingEntity target;

    public AutoStunSlam() {
        super("AutoStunSlam", Category.COMBAT);
        minFall.showIf(needFall::get);
    }

    @Override
    public void onDisable() {
        running = false;
        target = null;
        Combat.busy = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (cooldown > 0) cooldown--;
        ClientPlayerEntity p = mc.player;

        if (running) {
            if (target == null || !target.isAlive() || Combat.reach(p, target) > range.get() + 0.6) {
                finish(mc);
                return;
            }
            if (--wait <= 0) hitMace(mc);
            return;
        }

        if (mc.currentScreen != null || Combat.busy || cooldown > 0) return;
        // "Weapon Only": you must be holding the axe to start the combo.
        if (weaponOnly.get() && !ItemUtil.isAxe(p.getMainHandStack())) return;
        if (needFall.get() && !(p.fallDistance > minFall.get())) return;

        int axeSlot = ItemUtil.isAxe(p.getMainHandStack())
                ? Combat.selected(mc)
                : ItemUtil.findHotbar(p, ItemUtil::isAxe);
        maceSlot = ItemUtil.findMace(p, "breach");
        if (axeSlot < 0 || maceSlot < 0) return;

        LivingEntity t = Combat.find(mc, range.get(), 360, targets.is("Hostile"));
        if (t == null) return;
        if (shieldOnly.get() && !t.isBlocking()) return;

        target = t;
        prevSlot = Combat.selected(mc);
        Combat.busy = true;
        running = true;

        float[] rot = Combat.rotsTo(p, t);
        if (axeSlot != prevSlot) Combat.select(mc, axeSlot);
        Combat.silentLook(mc, rot[0], rot[1]);
        Combat.attack(mc, t);

        wait = ticks.getInt();
        if (wait == 0) hitMace(mc);
    }

    private void hitMace(MinecraftClient mc) {
        float[] rot = Combat.rotsTo(mc.player, target);
        Combat.select(mc, maceSlot);
        Combat.silentLook(mc, rot[0], rot[1]);
        Combat.attack(mc, target);
        finish(mc);
    }

    private void finish(MinecraftClient mc) {
        if (swapBack.get() && prevSlot >= 0) Combat.select(mc, prevSlot);
        running = false;
        target = null;
        prevSlot = -1;
        Combat.busy = false;
        cooldown = 20;
    }
}
