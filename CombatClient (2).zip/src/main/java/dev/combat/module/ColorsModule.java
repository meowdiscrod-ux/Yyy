package dev.combat.module;

import dev.combat.setting.BoolSetting;
import dev.combat.setting.NumSetting;

/** The color changer. Drives the accent color used across the GUI. */
public class ColorsModule extends Module {
    public static ColorsModule INSTANCE;

    private final NumSetting hue = add(new NumSetting("Hue", 0, 0, 360, 1));
    private final NumSetting sat = add(new NumSetting("Saturation", 0, 0, 100, 1));
    private final NumSetting bri = add(new NumSetting("Brightness", 100, 30, 100, 1));
    private final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    private final NumSetting rainbowSpeed = add(new NumSetting("Rainbow Speed", 20, 1, 100, 1));

    public ColorsModule() {
        super("Colors", Category.MISC);
        INSTANCE = this;
        rainbowSpeed.showIf(rainbow::get);
        setEnabled(true);
    }

    public static int accent() {
        ColorsModule m = INSTANCE;
        if (m == null || !m.isEnabled()) return 0xFFFFFFFF;
        float h;
        if (m.rainbow.get()) {
            long period = Math.max(500L, (long) (200000.0 / m.rainbowSpeed.get()));
            h = (System.currentTimeMillis() % period) / (float) period;
        } else {
            h = m.hue.getFloat() / 360f;
        }
        return hsv(h, m.sat.getFloat() / 100f, m.bri.getFloat() / 100f);
    }

    private static int hsv(float h, float s, float v) {
        float c = v * s;
        float hh = (h - (float) Math.floor(h)) * 6f;
        float x = c * (1f - Math.abs(hh % 2f - 1f));
        float m = v - c;
        float r, g, b;
        switch ((int) hh % 6) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return 0xFF000000 | ((int) ((r + m) * 255) << 16) | ((int) ((g + m) * 255) << 8) | (int) ((b + m) * 255);
    }
}
