package dev.combat;

import dev.combat.gui.ClickGui;
import dev.combat.module.*;
import dev.combat.util.Combat;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class CombatClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("CombatClient");
    public static final List<Module> MODULES = new ArrayList<>();

    private static boolean shiftWasDown;

    @Override
    public void onInitializeClient() {
        MODULES.add(new AutoMace());
        MODULES.add(new AutoStunSlam());
        MODULES.add(new TriggerBot());
        MODULES.add(new AimAssist());
        MODULES.add(new AutoSprint());
        MODULES.add(new Fullbright());
        MODULES.add(new AutoRespawn());
        MODULES.add(new ColorsModule());
        Config.load();

        // END tick so camera changes interpolate smoothly between ticks.
        ClientTickEvents.END_CLIENT_TICK.register(CombatClient::tick);
    }

    private static void tick(MinecraftClient mc) {
        // Right Shift opens/closes the GUI, in the main menu and in game.
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        boolean pressed = down && !shiftWasDown;
        shiftWasDown = down;
        if (pressed) {
            Screen cur = mc.currentScreen;
            if (cur instanceof ClickGui gui) {
                gui.close();
            } else if (!(cur != null && cur.getFocused() instanceof TextFieldWidget)) {
                mc.setScreen(new ClickGui(cur));
            }
        }

        if (mc.player == null || mc.world == null) return;
        for (Module m : MODULES) {
            if (!m.isEnabled()) continue;
            try {
                m.onTick(mc);
            } catch (Throwable t) {
                LOG.error("Module {} crashed, disabling it", m.name, t);
                m.setEnabled(false);
                Combat.busy = false;
            }
        }
    }
}
