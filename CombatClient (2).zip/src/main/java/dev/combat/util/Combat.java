package dev.combat.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Combat {
    private Combat() {}

    /** True while a multi-tick sequence (stun slam) owns the hotbar. Other modules stay out. */
    public static boolean busy;

    public static boolean isValid(Entity e, boolean hostileOnly) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!(e instanceof LivingEntity le) || e == mc.player) return false;
        if (!le.isAlive() || le.isSpectator() || e instanceof ArmorStandEntity) return false;
        if (e instanceof TameableEntity t && t.isTamed()) return false;
        return !hostileOnly || e instanceof Monster;
    }

    /** Distance from the player's eyes to the closest point of the target's hitbox. */
    public static double reach(Entity self, Entity target) {
        Vec3d eye = self.getEyePos();
        Box b = target.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** {yaw, pitch} that points the player's eyes at the target's hitbox center. */
    public static float[] rotsTo(Entity self, Entity target) {
        Vec3d eye = self.getEyePos();
        Vec3d p = target.getBoundingBox().getCenter();
        double dx = p.x - eye.x, dy = p.y - eye.y, dz = p.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    /** Nearest valid target inside range and inside the FOV cone (fov 360 = everything). */
    public static LivingEntity find(MinecraftClient mc, double range, double fov, boolean hostileOnly) {
        ClientPlayerEntity p = mc.player;
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!isValid(e, hostileOnly)) continue;
            double d = reach(p, e);
            if (d > range || d >= bestDist) continue;
            if (fov < 360) {
                float[] r = rotsTo(p, e);
                float dyaw = Math.abs(MathHelper.wrapDegrees(r[0] - p.getYaw()));
                float dpitch = Math.abs(r[1] - p.getPitch());
                if (dyaw > fov / 2.0 || dpitch > fov / 2.0) continue;
            }
            best = (LivingEntity) e;
            bestDist = d;
        }
        return best;
    }

    /** Eases the real camera toward the given rotation. speed is 1..100. Returns the remaining error in degrees. */
    public static float smooth(ClientPlayerEntity p, float yaw, float pitch, double speed, boolean vertical) {
        float f = (float) (speed / 100.0);
        float maxStep = (float) (5.0 + speed * 0.6);
        float dyaw = MathHelper.wrapDegrees(yaw - p.getYaw());
        float dpitch = pitch - p.getPitch();
        float sy = MathHelper.clamp(dyaw * f, -maxStep, maxStep);
        float sp = MathHelper.clamp(dpitch * f, -maxStep, maxStep);
        if (Math.abs(dyaw) < 0.4f) sy = dyaw;
        if (Math.abs(dpitch) < 0.4f) sp = dpitch;
        p.setYaw(p.getYaw() + sy);
        if (vertical) p.setPitch(MathHelper.clamp(p.getPitch() + sp, -90f, 90f));
        return (float) Math.hypot(dyaw - sy, vertical ? dpitch - sp : 0);
    }

    /** Silent aim: only the server is told about the rotation, the camera never moves. */
    public static void silentLook(MinecraftClient mc, float yaw, float pitch) {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, pitch, mc.player.isOnGround(), mc.player.horizontalCollision));
    }

    /** Attacks the entity directly (not through the crosshair) so it never depends on aim. */
    public static void attack(MinecraftClient mc, Entity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    public static int selected(MinecraftClient mc) {
        return mc.player.getInventory().getSelectedSlot();
    }

    public static void select(MinecraftClient mc, int slot) {
        mc.player.getInventory().setSelectedSlot(slot);
    }
}
