package dev.combat.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.enchantment.Enchantment;

import java.util.function.Predicate;

/** Item checks are done on registry ids so they don't depend on tag/class names. */
public final class ItemUtil {
    private ItemUtil() {}

    public static String id(ItemStack s) {
        return s.isEmpty() ? "" : Registries.ITEM.getId(s.getItem()).getPath();
    }

    public static boolean isSword(ItemStack s) { return id(s).endsWith("_sword"); }
    public static boolean isAxe(ItemStack s) { return id(s).endsWith("_axe"); }
    public static boolean isSpear(ItemStack s) { return id(s).endsWith("_spear"); }
    public static boolean isMace(ItemStack s) { return id(s).equals("mace"); }

    public static boolean isWeapon(ItemStack s) {
        return isSword(s) || isAxe(s) || isSpear(s) || isMace(s) || id(s).equals("trident");
    }

    public static boolean hasEnchant(ItemStack s, String path) {
        if (s.isEmpty()) return false;
        for (RegistryEntry<Enchantment> e : s.getEnchantments().getEnchantments()) {
            if (e.getKey().map(k -> k.getValue().getPath().equals(path)).orElse(false)) return true;
        }
        return false;
    }

    public static int findHotbar(ClientPlayerEntity p, Predicate<ItemStack> test) {
        for (int i = 0; i < 9; i++) {
            if (test.test(p.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    /** Finds a mace in the hotbar, preferring one with the given enchant (e.g. "breach", "density"). */
    public static int findMace(ClientPlayerEntity p, String preferredEnchant) {
        int fallback = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!isMace(s)) continue;
            if (preferredEnchant != null && hasEnchant(s, preferredEnchant)) return i;
            if (fallback == -1) fallback = i;
        }
        return fallback;
    }
}
