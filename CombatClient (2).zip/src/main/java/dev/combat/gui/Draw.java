package dev.combat.gui;

import net.minecraft.client.gui.DrawContext;

final class Draw {
    private Draw() {}

    /** Filled rounded rectangle built from plain fills (no overlap, so alpha colors stay clean). */
    static void rrect(DrawContext c, int x1, int y1, int x2, int y2, int r, int color) {
        int w = x2 - x1, h = y2 - y1;
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x1, y1, x2, y2, color);
            return;
        }
        c.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x1 + dx, y1 + i, x2 - dx, y1 + i + 1, color);
            c.fill(x1 + dx, y2 - i - 1, x2 - dx, y2 - i, color);
        }
    }

    /** Rounded rectangle with a 1px border. */
    static void rrectBorder(DrawContext c, int x1, int y1, int x2, int y2, int r, int fill, int border) {
        rrect(c, x1 - 1, y1 - 1, x2 + 1, y2 + 1, r + 1, border);
        rrect(c, x1, y1, x2, y2, r, fill);
    }
}
