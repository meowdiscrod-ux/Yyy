package dev.combat.gui;

import dev.combat.CombatClient;
import dev.combat.Config;
import dev.combat.module.Category;
import dev.combat.module.ColorsModule;
import dev.combat.module.Module;
import dev.combat.setting.BoolSetting;
import dev.combat.setting.ModeSetting;
import dev.combat.setting.NumSetting;
import dev.combat.setting.Setting;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Five-column click GUI.
 *  - Left click a module: toggle it.
 *  - Right click a module, or tap the dotted handle on its left: open its settings.
 *  - Mouse wheel scrolls the column under the cursor. Drag sliders with the mouse / finger.
 */
public class ClickGui extends Screen {
    private static final int GAP = 8, HEADER_H = 20, ROW_H = 17, SEARCH_W = 130, SEARCH_H = 14;

    private static final int C_HEADER = 0xFF202024;
    private static final int C_HEADER_BORDER = 0xFF303036;
    private static final int C_PANEL = 0xE0121215;
    private static final int C_PANEL_BORDER = 0xFF232328;
    private static final int C_ROW_ON = 0xFF2c2c32;
    private static final int C_ROW_HOVER = 0xFF1f1f23;
    private static final int C_SETTINGS = 0xFF18181b;
    private static final int C_TEXT_ON = 0xFFFFFFFF;
    private static final int C_TEXT_OFF = 0xFF8a8a92;
    private static final int C_TEXT_SET = 0xFFC8C8CE;
    private static final int C_TRACK = 0xFF3c3c42;

    private interface HitHandler {
        void click(int button, double mx);
    }

    private record Hit(int x1, int y1, int x2, int y2, HitHandler handler) {}

    private static final float[] SCROLL = new float[Category.values().length];

    private final Screen parent;
    private final int[] maxScroll = new int[Category.values().length];
    private final List<Hit> hits = new ArrayList<>();

    private TextFieldWidget search;
    private String searchText = "";

    private NumSetting dragging;
    private int dragX1, dragX2;

    private int clipX1, clipY1, clipX2, clipY2;
    private int colW, x0, y0, panelY, panelH, searchX, searchY;

    public ClickGui(Screen parent) {
        super(Text.literal("Combat Client"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        computeLayout();
        search = new TextFieldWidget(textRenderer, searchX + 8, searchY + 3, SEARCH_W - 30, 10, Text.literal("Search"));
        search.setDrawsBackground(false);
        search.setPlaceholder(Text.literal("Search for module..."));
        search.setText(searchText);
        search.setChangedListener(s -> searchText = s);
        addSelectableChild(search);
    }

    private void computeLayout() {
        int cols = Category.values().length;
        colW = Math.min(118, (width - 20 - GAP * (cols - 1)) / cols);
        int totalW = colW * cols + GAP * (cols - 1);
        x0 = (width - totalW) / 2;
        panelH = Math.max(90, Math.min(210, height - 110));
        int totalH = HEADER_H + 6 + panelH + 10 + SEARCH_H;
        y0 = Math.max(4, (height - totalH) / 2);
        panelY = y0 + HEADER_H + 6;
        searchX = (width - SEARCH_W) / 2;
        searchY = panelY + panelH + 10;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        Config.save();
        if (client != null) client.setScreen(parent);
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta); // dimmed + blurred background
        computeLayout();
        hits.clear();

        if (dragging != null) {
            long window = client.getWindow().getHandle();
            if (GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS) {
                updateDrag(mx);
            } else {
                dragging = null;
            }
        }

        String q = searchText.trim().toLowerCase();
        Category[] cats = Category.values();
        for (int c = 0; c < cats.length; c++) {
            drawColumn(ctx, c, cats[c], x0 + c * (colW + GAP), mx, my, q);
        }

        Draw.rrectBorder(ctx, searchX, searchY, searchX + SEARCH_W, searchY + SEARCH_H, 5, 0xFF16161a, C_HEADER_BORDER);
        search.render(ctx, mx, my, delta);
    }

    private void drawColumn(DrawContext ctx, int c, Category cat, int x, int mx, int my, String q) {
        Draw.rrectBorder(ctx, x, y0, x + colW, y0 + HEADER_H, 4, C_HEADER, C_HEADER_BORDER);
        int tw = textRenderer.getWidth(cat.label);
        ctx.drawText(textRenderer, cat.label, x + (colW - tw) / 2, y0 + (HEADER_H - 8) / 2, C_TEXT_ON, false);

        Draw.rrectBorder(ctx, x, panelY, x + colW, panelY + panelH, 5, C_PANEL, C_PANEL_BORDER);

        clipX1 = x + 3;
        clipY1 = panelY + 3;
        clipX2 = x + colW - 3;
        clipY2 = panelY + panelH - 3;
        ctx.enableScissor(clipX1, clipY1, clipX2, clipY2);

        int startY = clipY1 - (int) SCROLL[c];
        int y = startY;
        for (Module m : CombatClient.MODULES) {
            if (m.category != cat) continue;
            if (!q.isEmpty() && !m.name.toLowerCase().contains(q)) continue;
            y += drawModule(ctx, m, clipX1, y, clipX2 - clipX1, mx, my);
        }
        ctx.disableScissor();

        maxScroll[c] = Math.max(0, (y - startY) - (clipY2 - clipY1));
        SCROLL[c] = Math.max(0, Math.min(maxScroll[c], SCROLL[c]));
    }

    private int drawModule(DrawContext ctx, Module m, int x, int y, int w, int mx, int my) {
        boolean on = m.isEnabled();
        boolean hover = inClip(mx, my) && mx >= x && mx < x + w && my >= y && my < y + ROW_H;
        if (on) Draw.rrect(ctx, x, y, x + w, y + ROW_H, 3, C_ROW_ON);
        else if (hover) Draw.rrect(ctx, x, y, x + w, y + ROW_H, 3, C_ROW_HOVER);

        // dotted handle
        for (int i = 0; i < 3; i++) {
            ctx.fill(x + 4, y + 5 + i * 3, x + 5, y + 6 + i * 3, 0xFF55555c);
            ctx.fill(x + 7, y + 5 + i * 3, x + 8, y + 6 + i * 3, 0xFF55555c);
        }
        ctx.drawText(textRenderer, m.name, x + 12, y + (ROW_H - 8) / 2, on ? C_TEXT_ON : C_TEXT_OFF, false);

        // toggle pill
        int tx = x + w - 19, ty = y + (ROW_H - 7) / 2;
        Draw.rrect(ctx, tx, ty, tx + 14, ty + 7, 3, on ? ColorsModule.accent() : C_TRACK);
        int kx = on ? tx + 8 : tx + 1;
        Draw.rrect(ctx, kx, ty + 1, kx + 5, ty + 6, 2, on ? 0xFF18181b : 0xFF8a8a92);

        hit(x, y, x + 12, y + ROW_H, (b, cx) -> m.expanded = !m.expanded);
        hit(x + 12, y, x + w, y + ROW_H, (b, cx) -> {
            if (b == 0) m.toggle();
            else if (b == 1) m.expanded = !m.expanded;
        });

        if (!m.expanded) return ROW_H + 3;

        int sy = y + ROW_H + 1;
        int h = 8;
        for (Setting s : m.settings) if (s.visible()) h += settingHeight(s);
        Draw.rrect(ctx, x, sy, x + w, sy + h, 3, C_SETTINGS);
        int cy = sy + 4;
        for (Setting s : m.settings) {
            if (!s.visible()) continue;
            cy += drawSetting(ctx, s, x + 6, cy, w - 12, mx, my);
        }
        return ROW_H + 1 + h + 3;
    }

    private int settingHeight(Setting s) {
        if (s instanceof NumSetting) return 22;
        if (s instanceof ModeSetting ms) return 13 + ms.modes.length * 10;
        return 13;
    }

    private int drawSetting(DrawContext ctx, Setting s, int x, int y, int w, int mx, int my) {
        int accent = ColorsModule.accent();

        if (s instanceof BoolSetting b) {
            ctx.drawText(textRenderer, b.name, x, y + 2, C_TEXT_SET, false);
            int bx = x + w - 8;
            Draw.rrect(ctx, bx, y + 2, bx + 8, y + 10, 2, C_TRACK);
            if (b.get()) Draw.rrect(ctx, bx + 1, y + 3, bx + 7, y + 9, 1, accent);
            hit(x, y, x + w, y + 13, (btn, cx) -> b.toggle());
        } else if (s instanceof NumSetting n) {
            ctx.drawText(textRenderer, n.name, x, y + 1, C_TEXT_SET, false);
            String v = n.display();
            ctx.drawText(textRenderer, v, x + w - textRenderer.getWidth(v), y + 1, C_TEXT_OFF, false);
            int by = y + 14;
            ctx.fill(x, by, x + w, by + 2, C_TRACK);
            int fx = x + (int) (w * n.fraction());
            ctx.fill(x, by, fx, by + 2, accent);
            ctx.fill(fx - 1, by - 2, fx + 2, by + 4, 0xFFFFFFFF);
            hit(x - 2, y + 9, x + w + 2, y + 21, (btn, cx) -> {
                if (btn != 0) return;
                dragging = n;
                dragX1 = x;
                dragX2 = x + w;
                updateDrag(cx);
            });
        } else if (s instanceof ModeSetting ms) {
            ctx.drawText(textRenderer, ms.name, x, y + 1, C_TEXT_SET, false);
            String v = ms.get();
            ctx.drawText(textRenderer, v, x + w - textRenderer.getWidth(v), y + 1, C_TEXT_OFF, false);
            for (int i = 0; i < ms.modes.length; i++) {
                int oy = y + 12 + i * 10;
                boolean sel = ms.index() == i;
                Draw.rrect(ctx, x + 2, oy + 1, x + 8, oy + 7, 3, sel ? accent : C_TRACK);
                ctx.drawText(textRenderer, ms.modes[i], x + 12, oy, sel ? C_TEXT_ON : C_TEXT_OFF, false);
                final int idx = i;
                hit(x, oy, x + w, oy + 10, (btn, cx) -> ms.set(idx));
            }
        }
        return settingHeight(s);
    }

    private void updateDrag(double mx) {
        if (dragging == null || dragX2 <= dragX1) return;
        dragging.setFraction((mx - dragX1) / (double) (dragX2 - dragX1));
    }

    private boolean inClip(double mx, double my) {
        return mx >= clipX1 && mx < clipX2 && my >= clipY1 && my < clipY2;
    }

    /** Registers a clickable rectangle, clipped to the column that is currently being drawn. */
    private void hit(int x1, int y1, int x2, int y2, HitHandler handler) {
        x1 = Math.max(x1, clipX1);
        y1 = Math.max(y1, clipY1);
        x2 = Math.min(x2, clipX2);
        y2 = Math.min(y2, clipY2);
        if (x1 >= x2 || y1 >= y2) return;
        hits.add(new Hit(x1, y1, x2, y2, handler));
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int button = click.button();

        if (!search.isMouseOver(mx, my)) search.setFocused(false);

        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx >= h.x1() && mx < h.x2() && my >= h.y1() && my < h.y2()) {
                h.handler().click(button, mx);
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (int c = 0; c < Category.values().length; c++) {
            int x = x0 + c * (colW + GAP);
            if (mouseX >= x && mouseX < x + colW && mouseY >= panelY && mouseY < panelY + panelH) {
                SCROLL[c] = Math.max(0, Math.min(maxScroll[c], SCROLL[c] - (float) verticalAmount * 14f));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
}
